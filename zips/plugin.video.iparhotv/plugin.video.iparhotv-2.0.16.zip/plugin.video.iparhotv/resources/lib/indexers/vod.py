# -*- coding: utf-8 -*-

# AliveGR Addon
# Author Twilight0
# SPDX-License-Identifier: GPL-3.0-only
# See LICENSES/GPL-3.0-only for more information.

import re
import json
import unicodedata
import traceback
from http.client import HTTPException
from concurrent.futures import ThreadPoolExecutor
from xbmcaddon import Addon
from urllib.parse import urljoin, urlparse, parse_qsl

from tulip import directory, kodi, cleantitle
from tulip.utils import list_divider
from netclient import Net
from useragents import spoofer
from itertags import iwrapper
from ..modules.themes import iconname
from ..modules.constants import (
    cache_function, cache_method, cache_duration, separator, GM_BASE, GM_MOVIES, GM_SHOWS, GM_SERIES, GM_ANIMATION,
    GM_THEATER, GM_SPORTS, GM_SHORTFILMS, GM_MUSIC, GM_SEARCH, GM_PERSON, GM_EPISODE, VOD_FILTER_MAP,
    VOD_YEAR_FILTER_MAP, VOD_GENRE_FILTER_MAP, GENRES, GF_BASE, GFK_GETTER, GFM_GETTER
)
from ..modules.utils import page_menu, lists_merger
from ..modules.source_makers import gist_getter
from ..modules.errors import SiteUnavailable


DEFAULT_IMG = 'https://openclipart.org/image/800px/144715'


def get_genres(item):
    genres = item.get('genre') or 'άλλο'
    return genres if isinstance(genres, list) else [genres]


def spoof_images(items):
    return [dict(item, image=spoofer(item.get('image') or DEFAULT_IMG)) for item in items]


def bookmark_cm(item):
    bookmark = {k: v for k, v in item.items() if k != 'next'}
    bookmark['bookmark'] = item['url']
    return {'title': 30080, 'query': {'action': 'addBookmark', 'url': json.dumps(bookmark)}}


def gm_fetch(url, post=None):
    """Fetch a greek-movies.com page, raising SiteUnavailable rather than returning nothing.

    Every caller is wrapped in pickled.FunctionCache, which stores whatever a function
    returns - an empty result included - for twelve hours, but stores nothing when the
    function raises. So the one way to keep a blocked or broken site out of the cache is
    to raise, and the router turns that raise into a notification instead of a red X.

    Network, SSL and HTTP-protocol failures are the family an ISP block produces. In
    Python 3 urllib's URLError and HTTPError, ssl.SSLError and socket.timeout are all
    OSError, and netclient lets every one of them propagate (it only intercepts a
    Cloudflare 403 to retry). Code bugs - AttributeError, IndexError, KeyError - are
    deliberately not caught here, so they still surface in the log.
    """
    try:
        response = Net().http_POST(url, form_data=post) if post else Net().http_GET(url)
        html = response.content
    except (OSError, HTTPException) as error:
        raise SiteUnavailable(url) from error
    except Exception as error:
        # netclient escalates an unbeatable Cloudflare challenge as resolveurl's
        # ResolverError. Treat that as unreachable too, matched by name so the listing
        # path does not have to import resolveurl. Its handling of a Cloudflare 403 that
        # carries no challenge header (a WAF or IP-reputation block) trips over its own
        # retry code and raises TypeError or UnboundLocalError instead; those count as
        # unreachable only when the traceback shows they were raised inside netclient,
        # so a bug in this add-on can never be dressed up as a network problem.
        raised_in_netclient = any(
            'netclient' in frame.filename for frame in traceback.extract_tb(error.__traceback__)
        )
        if type(error).__name__ == 'ResolverError' or (
            isinstance(error, (TypeError, UnboundLocalError)) and raised_in_netclient
        ):
            raise SiteUnavailable(url) from error
        raise
    if not html:
        # HttpResponse.content swallows decode errors and hands back an empty string,
        # and no real greek-movies page is empty.
        raise SiteUnavailable(url)
    return html


def _strip_accents(text):
    return ''.join(c for c in unicodedata.normalize('NFD', text) if unicodedata.category(c) != 'Mn')


def month_number(text, months):
    """Map a Greek month abbreviation from the page to '01'..'12'.

    The page is not consistent about accents, surrounding whitespace or a trailing full
    stop, so the lookup tolerates all three. On a miss the cleaned text itself is returned
    rather than a made-up January: a wrong month is worse than an honest one, and it makes
    a new abbreviation visible instead of silently filing every episode under 01.
    """
    cleaned = text.strip().rstrip('.').strip()
    if cleaned in months:
        return months[cleaned]
    folded = _strip_accents(cleaned).lower()
    for key, number in months.items():
        if _strip_accents(key).lower() == folded:
            return number
    return cleaned


@cache_function(cache_duration(720))
def filtration(url):

    indexer = dict(parse_qsl(urlparse(url).query))

    l_index = indexer.get('l')
    y_index = indexer.get('y')
    g_index = indexer.get('g')
    gf_movies_list = gist_getter(GFM_GETTER)

    if l_index in VOD_FILTER_MAP:

        allowed_starts = VOD_FILTER_MAP[l_index]
        return spoof_images(item for item in gf_movies_list if item['label'].upper()[0] in allowed_starts)

    elif y_index in VOD_YEAR_FILTER_MAP:

        allowed_years = VOD_YEAR_FILTER_MAP[y_index]
        return spoof_images(item for item in gf_movies_list if item.get('year') in allowed_years)

    elif g_index in VOD_GENRE_FILTER_MAP:

        allowed_genres = [genre.lower() for genre in VOD_GENRE_FILTER_MAP[g_index]]
        genres_lower = {k.lower(): v for k, v in GENRES.items()}

        gf_movies_list = spoof_images(
            item for item in gf_movies_list if any(g.lower() in allowed_genres for g in get_genres(item))
        )

        for item in gf_movies_list:
            item['genre'] = [genres_lower.get(g.lower(), g) for g in get_genres(item)] if 'genre' in item else [kodi.i18n(30089)]

        return gf_movies_list

    return []


@cache_function(cache_duration(720))
def gm_root(url):

    root_list = []
    groups_list = []

    html = gm_fetch(url)

    # A section index is never legitimately empty: if the element every real page carries
    # is missing, the page is not a greek-movies page (a block page, a redirect, changed
    # markup). Raise so the cache stays empty instead of memorising a blank index.
    if url == GM_SPORTS:

        sports_index = next(iwrapper(html, 'div', attrs={'class': 'col-xs-6 text-center'}), None)
        if sports_index is None:
            raise SiteUnavailable(url, 'structure')
        return sports_index.text

    elif url == GM_MUSIC:

        music_index = next(iwrapper(html, 'div', attrs={'class': 'col-sm-5 col-md-4'}), None)
        if music_index is None:
            raise SiteUnavailable(url, 'structure')
        return music_index.text

    else:

        result_el = next(iwrapper(html, 'div', attrs={'class': 'row', 'style': 'margin-bottom: 20px;'}), None)
        if result_el is None:
            raise SiteUnavailable(url, 'structure')
        result = result_el.text
        items = re.findall('(<option  ?value=.*?</option>)', result, re.U) if result else []
        groups = iwrapper(result, 'option', attrs={'selected': None})

        groups_map = {
            u'ΑΡΧΙΚΑ': '30213', u'ΕΤΟΣ': '30090', u'ΚΑΝΑΛΙ': '30211', u'ΕΙΔΟΣ': '30200', u'ΠΑΡΑΓΩΓΗ': '30212'
        }

        for group_match in groups:

            groups_list.append(groups_map.get(group_match.text, group_match.text))

        for item in items:

            link = next(iwrapper(item, 'option', ret='value'), '')
            name_el = next(iwrapper(item, 'option', attrs={'value': '.+?.php.+?'}), None)
            if not link or name_el is None:
                continue
            indexer = urlparse(link).query
            index = urljoin(GM_BASE, link)

            name = name_el.text

            if indexer.startswith('g='):

                for entity, trans in GENRES.items():
                    name = name.replace(entity, trans)

            if GM_MOVIES in url:
                name = name.replace(u'σήμερα', kodi.i18n(30268))

            title = name[0].capitalize() + name[1:]

            group = {'l=': '30213', 'y=': '30090', 'c=': '30211', 'g=': '30200', 'p=': '30212'}.get(indexer[:2], '')

            root_list.append({'title': title, 'group': group, 'url': index})

        return root_list, groups_list


class Indexer:

    def __init__(self):

        self.list = []
        self.data = []

        self.switch = {
            'title': kodi.i18n(30045).format(kodi.i18n(int(Addon().getSetting('vod_group')))),
            'icon': iconname('switcher'), 'action': 'vod_switcher', 'isFolder': 'False', 'isPlayable': 'False'
        }

        self.group_changer = {'action': 'vod_switcher'}

    def vod_switcher(self, url):

        _, self.data = gm_root(url)

        translated = [kodi.i18n(int(i)) for i in self.data]

        choice = kodi.selectDialog(heading=kodi.i18n(30062), list=translated)

        if choice <= len(self.data) and not choice == -1:
            Addon().setSetting('vod_group', self.data[choice])
            kodi.idle()
            kodi.sleep(100)  # ensure setting has been saved
        else:
            kodi.execute('Dialog.Close(all)')

    def gm_index(self, url, icon):

        self.data = gm_root(url)[0]

        vod_group = Addon().getSetting('vod_group')
        switcher_mode = Addon().getSetting('vod_switcher_mode')

        try:
            self.list = [item for item in self.data if item['group'] == vod_group]
        except Exception:
            kodi.setSetting('vod_group', '30213')
            self.list = self.data

        for item in self.list:

            item.update({'icon': iconname(icon), 'action': 'listing', 'isFolder': 'True'})

            if switcher_mode == '1':

                self.group_changer.update({'url': url})

                item.update({'cm': [{'title': 30034, 'query': self.group_changer}]})

        if switcher_mode == '0':

            self.switch.update({'url': url})

            self.list.insert(0, self.switch)

        directory.builder(self.list)

    def movies(self):
        self.gm_index(GM_MOVIES, 'movies')

    def short_films(self):
        self.gm_index(GM_SHORTFILMS, 'short')

    def series(self):
        self.gm_index(GM_SERIES, 'series')

    def shows(self):
        self.gm_index(GM_SHOWS, 'shows')

    def cartoons_series(self):
        self.gm_index(GM_ANIMATION, 'cartoon_series')

    def theater(self):
        self.gm_index(GM_THEATER, 'theater')

    @cache_method(cache_duration(720))
    def gm_items_list(self, url, post=None):

        indexer = urlparse(url).query

        if 'movies.php' in url:
            length = 10
        elif 'shortfilm.php' in url:
            length = 6
        elif 'theater.php' in url:
            length = 8
        else:
            length = 2

        tail = {'l=': '&g=&p=', 'g=': '&l=&p=', 'p=': '&l=&g=', 'c=': '&l=&g='}.get(indexer[:2])

        years = ['y={0}{1}'.format(year, tail) for year in range(1, length)] if tail else []

        if indexer.startswith(
                ('l=', 'g=', 's=', 'p=', 'c=')
        ) and ('movies.php' in url or 'shortfilm.php' in url or 'theater.php' in url) and years:

            base = GM_BASE + url.rpartition('/')[2].partition('&')[0]

            with ThreadPoolExecutor(max_workers=len(years) or 1) as ex:
                self.data = list(ex.map(lambda c: gm_fetch(base + '&' + c), years))

            result = u''.join(self.data)

            content = iwrapper(result, 'div', attrs={'class': 'col-xs-6 col-sm-4 col-md-3'})

        else:

            html = gm_fetch(url, post)

            content = iwrapper(html, 'div', attrs={'class': 'col-xs-6 col-sm-4 col-md-3'})

        contents = ''.join([i.text for i in list(content)])
        items = re.findall('(<a.*?href.*?div.*?</a>)', contents, re.U)

        for item in items:

            # Guarded: one malformed card on the page used to raise
            # StopIteration out of the whole listing, emptying the section.
            title_el = next(iwrapper(item, 'h4'), None)
            link = next(iwrapper(item, 'a', ret='href'), '')
            if title_el is None or not link:
                continue
            title = title_el.text

            image = next(iwrapper(item, 'img', ret='src'), '')
            image = urljoin(GM_BASE, image) if image else ''
            link = urljoin(GM_BASE, link)

            # Titles usually read "Name (2019)", but not always. .group() on a
            # miss raised AttributeError; an unparsed year is not a reason to
            # drop the item, so fall back to no year and the raw title.
            label = re.search(r'(.*?) \((\d{2,4})', title)
            if label:
                year = int(label.group(2))
                if year < 100:
                    year += 1900 if year >= 40 else 2000
                name = label.group(1)
            else:
                year = 0
                name = title.strip()

            self.list.append(
                {
                    'label': name, 'title': title, 'url': link, 'image': image, 'year': year, 'name': name
                }
            )

        return self.list

    def listing(self, url, post=None, get_listing=False):

        if 'gist.githubusercontent.com' in url:

            self.list = gist_getter(url)

        else:

            self.list = self.gm_items_list(url, post)

        if url.startswith(GM_MOVIES):

            gf_movies_list = filtration(url)

            if gf_movies_list:

                self.list = lists_merger(self.list, gf_movies_list, 'title')

        action_type = Addon().getSetting('action_type')

        for item in self.list:

            try:
                item['image'] = item['image'].replace('http://', 'https://')
            except AttributeError:
                item['image'] = DEFAULT_IMG

            item['url'] = item['url'].replace('http://', 'https://')

            if url.startswith(
                    (
                            GM_MOVIES, GM_THEATER, GM_SHORTFILMS, GM_PERSON, GM_SEARCH, GFK_GETTER
                    )
            ) and item['url'].startswith(
                (
                        GM_MOVIES, GM_THEATER, GM_SHORTFILMS, GM_PERSON, GF_BASE, GFK_GETTER
                )
            ) or isinstance(item.get('urls'), list):
                if action_type == '1':
                    item.update({'action': 'play'})
                else:
                    item.update({'action': 'play', 'isFolder': 'False', 'isPlayable': 'True'})
            elif url.startswith(GM_SPORTS):
                item.update({'action': 'events', 'isFolder': 'True'})
            else:
                item.update({'action': 'episodes', 'isFolder': 'True'})

        for item in self.list:

            refresh_cm = {'title': 30054, 'query': {'action': 'refresh'}}
            item.update({'cm': [bookmark_cm(item), refresh_cm]})

        if get_listing:

            return self.list

        if len(self.list) > int(Addon().getSetting('pagination_integer')) and Addon().getSetting('paginate_items') == 'true':

            if Addon().getSetting('sort_method') == '0':

                self.list.sort(
                    key=lambda k: cleantitle.strip_accents(k['title'].lower()),
                    reverse=Addon().getSetting('reverse_order') == 'true'
                )

            elif Addon().getSetting('sort_method') == '1':

                self.list.sort(key=lambda k: k['year'], reverse=Addon().getSetting('reverse_order') == 'true')

            try:

                pages = list_divider(self.list, int(Addon().getSetting('pagination_integer')))
                self.list = pages[int(Addon().getSetting('page'))]
                reset = False

            except Exception:

                pages = list_divider(self.list, int(Addon().getSetting('pagination_integer')))
                self.list = pages[0]
                reset = True

            if Addon().getSetting('pagination_function') == '0':
                self.list.insert(0, page_menu(str(len(pages)), reset=reset))
            elif Addon().getSetting('pagination_function') == '1':

                if not reset:
                    index = str(int(Addon().getSetting('page')) + 1)
                else:
                    index = '1'

                page_cm = {
                    'title': kodi.i18n(30414).format(index),
                    'query': {'action': 'page_selector', 'query': str(len(pages))}
                }

                for i in self.list:
                    # Append: assigning here used to replace the bookmark and
                    # refresh entries set above, removing them from every row.
                    i['cm'] = i.get('cm', []) + [page_cm]

        if Addon().getSetting('paginate_items') == 'false' or len(self.list) <= int(Addon().getSetting('pagination_integer')):

            kodi.setsortmethod(mask='%Y')
            kodi.setsortmethod('label', mask='%Y')
            kodi.setsortmethod('year')

        if url.startswith((GM_MOVIES, GM_THEATER, GM_SHORTFILMS)):
            directory.builder(self.list, content='movies', add_all_at_once=True)
        else:
            directory.builder(self.list, content='tvshows', add_all_at_once=True)

    @cache_method(cache_duration(720))
    def gm_epeisodia(self, url):

        # Every lookup here is guarded, restoring what 1.0.27 had and the 2.0.0
        # rebuild dropped. This function is reached ONLY by the 'episodes'
        # action - series, shows and cartoon series - because listing() sends
        # movies, theatre, short films, person and search to 'play' instead.
        # So a single missing element raised out of the plugin, and Kodi showed
        # its generic red X for exactly those sections while movies kept working.
        html = gm_fetch(url)

        image = next(iwrapper(html, 'img', attrs={'class': 'thumbnail.*?'}, ret='src'), '')
        image = urljoin(GM_BASE, image) if image else ''

        year_el = next(iwrapper(html, 'h4', attrs={'style': 'text-indent:10px;'}), None)
        if year_el is None:
            # The fallback selector was itself unguarded, so a page matching
            # neither style raised from inside the except clause.
            year_el = next(iwrapper(html, 'h4', attrs={'style': '^padding-left:10px;$'}), None)
        year_match = re.search(r'(\d{4})', year_el.text) if year_el is not None else None
        year = int(year_match.group(1)) if year_match else 0

        name_el = next(iwrapper(html, 'h2'), None)
        name = name_el.text if name_el is not None else ''

        # The episode container is on every real show page, even one with no episodes
        # yet. Its absence means this is not a show page at all, so raise rather than
        # return an empty list the cache would then serve for twelve hours. A container
        # that is present but empty still returns [] below, which is the honest answer.
        result_el = next(iwrapper(html, 'div', attrs={'style': 'margin:20px 0px 20px 0px;'}), None)
        if result_el is None:
            raise SiteUnavailable(url, 'structure')
        result = result_el.text

        episodes = re.findall(r'onclick="loadEpisode(.*?)">(.*?)</button>', result)

        plot = kodi.i18n(30085)
        if str('text-justify') in html:
            plot_el = next(iwrapper(html, 'p', attrs={'class': 'text-justify'}), None)
            if plot_el is not None:
                plot = plot_el.text

        # Genre is the second h4 of whichever style the page uses. Either list
        # can be shorter than two entries; indexing [1] blindly raised, and the
        # fallback then raised again from inside the handler for the first.
        genre = kodi.i18n(30147)
        for style in ('text-indent:10px;', 'padding-left:10px;'):
            info = list(iwrapper(html, 'h4', attrs={'style': style}, lazify=True))
            if len(info) > 1:
                genre = info[1].text.lstrip(u'Είδος:').strip() or kodi.i18n(30147)
                break

        dictionary = {
            u'Ιαν': '01', u'Φεβ': '02', u'Μάρ': '03',
            u'Απρ': '04', u'Μάι': '05', u'Ιούν': '06',
            u'Ιούλ': '07', u'Αύγ': '08', u'Σεπ': '09',
            u'Οκτ': '10', u'Νοέ': '11', u'Δεκ': '12'
        }

        sep = separator()

        for eid, title in episodes:

            link_match = re.search(r'\'([\w-]+)\', \'(\w{1,2})\'', eid)
            if not link_match:
                continue
            link = GM_EPISODE.format(link_match.group(1), link_match.group(2))

            if '\'n\')' in eid:
                group = '1bynumber'
                if '.' in title:
                    season = title.partition('.')[0]
                    episode_num = title.partition('.')[2]
                    title = kodi.i18n(30067) + ' ' + season + '.' + episode_num
                else:
                    title = kodi.i18n(30067) + ' ' + title
            elif '\'d\')' in eid:
                # Shows are listed by date where series are listed by number, so
                # this branch is reached almost only by shows. That is why shows
                # carried three failure sites series never reach - and why a
                # partial fix would look like it repaired series and left shows
                # still broken.
                group = '2bydate'
                row = result.split(eid)[0] if result else ''
                y_matches = re.findall(r'<h4.+?bold.+?(\d{4})', row, re.U)
                y = y_matches[-1] if y_matches else (str(year) if year else '0000')
                m_matches = re.findall(r'width:50px..?>(.+?)<', row, re.U)
                # No silent January: an unrecognised abbreviation is kept as-is and a
                # missing month is simply left out, giving DD-MM-YYYY or DD-YYYY.
                m = month_number(m_matches[-1], dictionary) if m_matches else ''
                prefix = '0' + title if len(title) == 1 else title
                title = '-'.join(part for part in (prefix, m, y) if part)
            else:
                group = '3bytitle'

            self.list.append(
                {
                    # A page without its <h2> gives an empty name; do not lead with a bare separator.
                    'label': (name + sep + title) if name else title,
                    'title': (name + ' - ' + title) if name else title,
                    'url': link, 'group': group,
                    'name': name, 'image': image, 'plot': plot, 'year': year,
                    'genre': [genre]
                }
            )

        return self.list

    def episodes(self, url):

        self.list = self.gm_epeisodia(url)

        refresh_cm = {'title': 30054, 'query': {'action': 'refresh'}}

        cm = [refresh_cm]

        action_type = Addon().getSetting('action_type')

        for item in self.list:

            # Per-episode "Select source": a long-press context action that opens the source
            # picker for this episode even when the global mode is Auto or Directory. Normal
            # click still follows the global setting; this only adds a menu entry.
            item_cm = [refresh_cm]
            if item.get('url'):
                item_cm.append(
                    {'title': 30966, 'query': {'action': 'play', 'url': item['url'], 'select': '1'}}
                )

            if action_type == '1':
                item.update({'action': 'directory', 'isFolder': 'True', 'isPlayable': 'False', 'cm': item_cm})
            else:
                item.update({'action': 'play', 'isFolder': 'False', 'isPlayable': 'True', 'cm': item_cm})

        if Addon().getSetting('episodes_reverse') == 'true':

            self.list = sorted(
                self.list,
                key=lambda k: k['group'] if k['group'] in ['1bynumber', '2bydate'] else k['title'], reverse=True
            )[::-1]

        else:

            self.list = sorted(self.list, key=lambda k: k['group'])

        if len(self.list) > int(Addon().getSetting('pagination_integer')) and Addon().getSetting('paginate_items') == 'true':

            try:

                pages = list_divider(self.list, int(Addon().getSetting('pagination_integer')))
                self.list = pages[int(Addon().getSetting('page'))]
                reset = False

            except Exception:

                pages = list_divider(self.list, int(Addon().getSetting('pagination_integer')))
                self.list = pages[0]
                reset = True

            if Addon().getSetting('pagination_function') == '0':
                self.list.insert(0, page_menu(str(len(pages)), reset=reset))
            elif Addon().getSetting('pagination_function') == '1':

                if not reset:
                    index = str(int(Addon().getSetting('page')) + 1)
                else:
                    index = '1'

                page_cm = {'title': kodi.i18n(30414).format(index), 'query': {'action': 'page_selector', 'query': str(len(pages))}}
                for i in self.list:
                    # Keep each episode's own menu (refresh + Select source); just add the page item.
                    i['cm'] = i.get('cm', [refresh_cm]) + [page_cm]

        kodi.setsortmethod()

        directory.builder(self.list, content='episodes', add_all_at_once=True)

    def gm_sports(self):

        html = gm_root(GM_SPORTS)

        options = re.compile('(<option value.+?</option>)', re.U).findall(html)

        icons = [
            'https://www.shareicon.net/data/256x256/2015/11/08/157712_sport_512x512.png',
            'https://www.shareicon.net/data/256x256/2015/12/07/196797_ball_256x256.png'
        ]

        items = list(zip(options, icons))

        for item, image in items:

            title_el = next(iwrapper(item, 'option'), None)
            url = next(iwrapper(item, 'option', ret='value'), '')
            if title_el is None or not url:
                continue
            title = title_el.text
            url = cleantitle.replaceHTMLCodes(url)
            index = urljoin(GM_BASE, url)

            data = {
                'title': title, 'action': 'listing', 'url': index,
                'image': image, 'isFolder': 'True', 'isPlayable': 'False'
            }
            self.list.append(data)

        directory.builder(self.list)

    @cache_method(cache_duration(720))
    def event_list(self, url):

        html = gm_fetch(url)
        items = list(iwrapper(html, 'div', attrs={'style': 'margin-bottom: 10px'}))

        if items:
            image = next(iwrapper(html, 'img', attrs={'class': 'thumbnail img-responsive pull-right'}, ret='src'), '')
            image = urljoin(GM_BASE, image) if image else ''

        for item in items:

            title_el = next(iwrapper(item.text, 'a', attrs={'class': 'btn btn-default'}), None)
            link = next(iwrapper(item.text, 'button', attrs={'class': 'btn btn-default'}, ret='href'), '')
            if title_el is None or not link:
                continue
            title = title_el.text
            link = urljoin(GM_BASE, link)
            plot_el = next(iwrapper(item.text, 'span', attrs={'class': 'pull-right'}), None)
            plot = plot_el.text if plot_el is not None else ''

            self.list.append(
                {
                    'title': title, 'url': link, 'plot': plot,
                    'image': image
                }
            )

        return self.list

    def events(self, url):

        self.list = self.event_list(url)

        for item in self.list:
            item.update({'cm': [bookmark_cm(item)], 'action': 'play', 'isFolder': 'False', 'isPlayable': 'True'})

        directory.builder(self.list)

    @cache_method(cache_duration(720))
    def persons_listing(self, url, post):

        html = gm_fetch(url, post)

        # Unlike the show page's episode container, a missing results block here is
        # routine: this is the person SEARCH, and a name with no hits simply has nothing
        # to list. An empty list is the honest answer, and caching it per query is
        # harmless, where a notice would turn every misspelled name into a false 'site
        # changed' diagnosis. A blocked or broken site still raises from gm_fetch above.
        content_el = next(iwrapper(html, 'div', attrs={'style': 'margin-left:20px;'}), None)
        if content_el is None:
            return self.list
        content = content_el.text

        persons = iwrapper(content, 'h4')

        for person in persons:

            title_el = next(iwrapper(person.text, 'a'), None)
            href = next(iwrapper(person.text, 'a', ret='href'), '')
            if title_el is None or not href:
                continue
            title = title_el.text
            url = urljoin(GM_BASE, href)

            i = {'title': title, 'url': url}

            self.list.append(i)

        return self.list

    def persons_index(self, url, post):

        self.list = self.persons_listing(url, post)

        if self.list is None:
            return

        for item in self.list:

            item.update({'action': 'listing', 'isFolder': 'True', 'icon': iconname('user')})

            refresh_cm = {'title': 30054, 'query': {'action': 'refresh'}}
            item.update({'cm': [bookmark_cm(item), refresh_cm]})

        return self.list
