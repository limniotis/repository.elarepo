# -*- coding: utf-8 -*-

# AliveGR Addon
# Author Twilight0
# SPDX-License-Identifier: GPL-3.0-only
# See LICENSES/GPL-3.0-only for more information.

import json
from urllib.parse import urlencode
from datetime import datetime
from time import monotonic
from tulip import directory, kodi
from tulip.log import log
from netclient import Net
from useragents import get_ua
from tulip.utils import py3_dec
from ..modules.utils import thgiliwt, pinned_from_file
from ..modules.themes import iconname
from ..modules.constants import (
    LIVE_GROUPS, M3U_GROUPS, cache_method, cache_duration, M3U_LINK, PINNED, ALIVEGR,
    ELAREPO_LIVE, ELAREPO_M3U
)
from ..modules import livedata
from ..modules.livedata import channel_key, sort_key, is_playlist, LastGood  # noqa: F401 (re-exported)


def _fetch(url, timeout, headers=None):

    if headers:
        return Net().http_GET(url, headers=headers, timeout=timeout).content

    return Net().http_GET(url, timeout=timeout).content


class Indexer:

    @staticmethod
    def switcher():

        groups = list(LIVE_GROUPS.values())
        translated = [kodi.i18n(i) for i in groups]
        choice = kodi.selectDialog(heading=kodi.i18n(30049), list=[kodi.i18n(30048)] + translated + [kodi.i18n(30282)])

        if choice != -1:
            kodi.setSetting('live_group', str(choice))
            kodi.idle()
            kodi.sleep(100)
            if str(choice) != kodi.setting('live_group'):
                kodi.refresh()
            else:
                kodi.execute('Dialog.Close(all)')

    @staticmethod
    def fetch_chain(urls, validate, headers=None):

        """
        Return the body of the first url that both answers and passes validate().

        Every tier is validated rather than merely fetched, because a host that answers 200 with
        a holding page would otherwise be served as though it were the channel list. Order is:
        the repo.elarepo.org website copy, then the original upstream. The website tier gets
        livedata.PRIMARY_TIMEOUT, the upstream keeps netclient's 20 s. If no tier survives, the
        last exception propagates, exactly as the unguarded final fallback used to, so a total
        outage is never cached as an empty list.
        """

        return livedata.fetch_chain(lambda url, timeout: _fetch(url, timeout, headers), urls, validate)

    @staticmethod
    def genre_names():
        """group id -> localised name, built once per list instead of once per channel."""

        return {group: kodi.i18n(group) for group in LIVE_GROUPS.values()}

    def merged_with_m3u(self, live_list, m3u_list, genre_names=None):

        """
        Fold the M3U playlist into the JSON channel list.

        The playlist was only reachable through the live_m3u action, which no menu links to, so
        its channels have been invisible. Merging here rather than in live_tv() means every
        consumer - live_tv(), modular(), search - sees one list.

        Best effort by design: the JSON list is the real one, so a playlist that is unreachable
        or malformed must not take Live TV down with it; the caller passes whatever it managed
        to fetch, or the last good playlist, or nothing.
        """

        if not m3u_list:
            return live_list

        return livedata.merge_m3u(
            live_list, m3u_list, LIVE_GROUPS, M3U_GROUPS, genre_names or self.genre_names(),
            datetime.now().year
        )

    @staticmethod
    def m3u_headers():

        return {'User-Agent': 'AliveGR, version: ' + kodi.version()}

    def m3u_text(self, headers):
        """The raw playlist, first tier that validates; raises when neither does."""

        return self.fetch_chain([ELAREPO_M3U, M3U_LINK], is_playlist, headers=headers)

    @staticmethod
    def last_good():

        # In the profile directory, not the function cache directory: the cache is wiped on
        # every update and on a manual clear, and the whole point of this copy is to still
        # have a list then.
        return LastGood(kodi.dataPath)

    def live(self):

        """
        The channel list, from the network when it answers and from the last good copy when it
        does not.

        fresh_live() is the eight-hour cached build and raises on a total failure, which keeps
        the failure out of that cache. This wrapper is what turns the failure into the last
        good list instead of an error, and what stops the network being retried on every open
        for livedata.RETRY_AFTER seconds after one.
        """

        store = self.last_good()

        if store.failed_recently():
            stale = store.load()
            if stale:
                log('Live TV: recent fetch failure, serving the last good list without retrying')
                return stale['list'], self.offline_marker(stale['updated'])

        started = monotonic()

        try:
            return self.fresh_live()
        except Exception as error:
            stale = store.load()
            if not stale:
                raise
            # A slow failure (the host timing out) is not retried for a while; an instant one
            # (no network yet) is cheap and is retried on the next open.
            if monotonic() - started >= livedata.SLOW_FAILURE:
                store.note_failure()
            log('Live TV: fetch failed ({0}), serving the last good list'.format(repr(error)))
            kodi.infoDialog(kodi.i18n(30961))
            return stale['list'], self.offline_marker(stale['updated'])

    @staticmethod
    def offline_marker(updated):

        return updated + ' ' + kodi.i18n(30960)

    @cache_method(cache_duration(480))
    def fresh_live(self):

        # The playlist is fetched on a worker while the JSON list is fetched here, so a cold
        # open costs the slower of the two chains instead of the sum. Only the raw fetch runs
        # on the worker; everything Kodi-facing stays on this thread.
        store = self.last_good()
        started = monotonic()
        m3u_future = livedata.Background(self.m3u_text, self.m3u_headers())

        if kodi.setting('debug') == 'false':

            # json.loads, not parse_channels, as the validator: a website copy that only
            # parses with the single-quote fallback falls through to upstream, as before.
            result = self.fetch_chain(
                [ELAREPO_LIVE, py3_dec(thgiliwt('=' + ALIVEGR))], json.loads
            )

        else:

            if kodi.setting('local_remote') == '0':
                local = kodi.setting('live_local')
                with open(local, encoding='utf-8') as _json:
                    result = _json.read()
            elif kodi.setting('local_remote') == '1':
                result = Net().http_GET(kodi.setting('live_remote')).content
            else:
                result = Net().http_GET(thgiliwt('=' + ALIVEGR)).content

        channels = livedata.parse_channels(result)
        # channels = [i for i in channel_list['channels'] if i['enable']]
        updated = channels['updated']
        live_list = []

        year = datetime.now().year
        genre_names = self.genre_names()

        lang_split = kodi.setting('lang_split')
        sys_lang = kodi.infoLabel('System.Language')

        for channel in channels['channels']:

            title = channel['name']
            image = channel['logo']
            group = channel['group']
            # .get(): one channel with an unknown group name must not take the whole Live TV
            # section down. Unknowns land in Web TV. This is the same guard-loss class that
            # 2.0.2 closed across vod.py.
            group = LIVE_GROUPS.get(group, LIVE_GROUPS['Web TV'])
            url = channel['url']
            website = channel['website']
            info = channel['info']
            headers = channel.get('headers')
            if headers == 'random':
                headers = {'User-Agent': get_ua(), 'Referer': website}
            drm = channel.get('drm')
            if drm:
                if not isinstance(headers, dict):
                    headers = {}
                headers.update({'DRM': json.dumps(drm)})

            if len(info) == 5 and info[:5].isdigit():
                info = kodi.i18n(int(info))

            if ' - ' in info:
                if lang_split == '1' or (lang_split == '0' and 'English' in sys_lang):
                    info = info.partition(' - ')[0]
                elif lang_split == '2' or (lang_split == '0' and 'Greek' in sys_lang):
                    info = info.partition(' - ')[2]

            data = {
                'title': title, 'image': image, 'group': str(group),
                'genre': genre_names[group], 'plot': info, 'website': website, 'year': year,
                'url': '|'.join([url[0], urlencode(headers)]) if headers else url[0]
            }

            live_list.append(data)

        # The playlist: what the worker fetched, else the last good playlist, else nothing. A
        # playlist hiccup used to cache a JSON-only list for eight hours; now the previous
        # playlist channels are kept until the next successful fetch.
        # The wait for the playlist is bounded by the budget its own chain has, counted from
        # the same start: a list that is already in hand is not held back for a playlist host
        # that is still timing out. Monotonic, so a clock step cannot cut the wait short.
        budget = livedata.PRIMARY_TIMEOUT + livedata.FALLBACK_TIMEOUT + livedata.WAIT_GRACE
        remaining = max(0.0, budget - (monotonic() - started))

        try:
            m3u_list = livedata.parse_m3u(m3u_future.result(timeout=remaining), kodi.addonInfo('icon'))
        except Exception as error:
            log('Live TV: playlist unavailable ({0}), keeping the last good playlist'.format(repr(error)))
            stale = store.load()
            m3u_list = stale['m3u'] if stale else []

        live_list = self.merged_with_m3u(live_list, m3u_list, genre_names)

        # Alphabetical whatever order either list is maintained in. live_tv() shows insertion
        # order (its first setsortmethod() is the unsorted one), and with the playlist merged
        # in that order had become the JSON list followed by every playlist channel. Sorting
        # here, inside the cached list, gives live_tv(), modular() and search the same order.
        live_list.sort(key=lambda item: sort_key(item['title']))

        if not store.save(live_list, updated, m3u_list):
            log('Live TV: could not keep the last good list in ' + store.path)

        return live_list, updated

    def live_tv(self, query=None):

        live_data, updated = self.live()

        live_group_str = kodi.setting('live_group')
        live_group = int(live_group_str) - 1
        switcher_mode = kodi.setting('live_switcher_mode')

        try:
            group = str(list(LIVE_GROUPS.values())[live_group])
        except IndexError:
            group = None

        if live_group_str not in ('0', '10') and query is None:

            live_data = [item for item in live_data if item['group'] == group]

        elif live_group_str == '10' and query is None:

            pinned = set(pinned_from_file(PINNED))
            live_data = [item for item in live_data if item['title'] in pinned]

        for item in live_data:

            item.update({'action': 'play', 'isPlayable': 'True', 'duration': None})

            if live_group_str == '10':
                pin_cm = {'title': 30337, 'query': {'action': 'unpin', 'query': item['title']}}
            else:
                pin_cm = {'title': 30336, 'query': {'action': 'pin', 'query': item['title']}}

            menu = [pin_cm]

            group_changer = {'title': 30034, 'query': {'action': 'live_switcher'}}

            if switcher_mode == '1':
                menu.insert(1, group_changer)

            if item['website'] != 'None':
                web_cm = {'title': 30316, 'query': {'action': 'open_link', 'url': item['website']}}
                menu.insert(2, web_cm)

            item.update({'cm': menu})

        if switcher_mode == '0':

            if live_group_str == '0':
                label = kodi.i18n(30048)
            elif live_group_str == '10':
                label = kodi.i18n(30282)
            else:
                label = kodi.i18n(int(group))

            switch = {
                'title': label,
                'image': iconname('switcher'),
                'action': 'live_switcher',
                'plot': kodi.i18n(30034) + '[CR]' + kodi.i18n(30035) + updated,
                'isFolder': 'False', 'isPlayable': 'False'
            }

            live_data.insert(0, switch)

        if query:

            return [i for i in live_data if query in i['title'].lower()]

        kodi.setsortmethod()
        kodi.setsortmethod('production_code')
        kodi.setsortmethod('title')
        kodi.setsortmethod('genre', mask='%C')

        directory.builder(live_data, content='videos', add_all_at_once=True)

    @cache_method(cache_duration(480))
    def cached_live_m3u(self):

        return livedata.parse_m3u(self.m3u_text(self.m3u_headers()), kodi.addonInfo('icon'))

    def live_m3u(self):

        m3u_list = self.cached_live_m3u()

        for i in m3u_list:
            i.update({'action': 'play', 'isFolder': 'False', 'isPlayable': 'True'})

        directory.builder(m3u_list, content='videos', as_playlist=kodi.setting('live_tv_mode') == '1')

    def modular(self, group):

        if group == '30125':
            fanart = 'https://i.ytimg.com/vi/vtjL9IeowUs/maxresdefault.jpg'
        elif group == '30032':
            fanart = 'https://cdn.iview.abc.net.au/thumbs/i/ls/LS1604H001S005786f5937ded19.22034349_1280.jpg'
        else:
            fanart = kodi.addonInfo('fanart')

        channel_list, _ = self.live()
        modular_list = [item for item in channel_list if item['group'] == group]

        year = datetime.now().year

        for item in modular_list:
            pin_cm = {'title': 30336, 'query': {'action': 'pin'}}
            item.update(
                {'action': 'play', 'isFolder': 'False', 'isPlayable': 'True',
                 'cm': [pin_cm], 'year': year, 'duration': None, 'fanart': fanart
                 }
            )

        # Same key as live(), so a modular view never orders accented names differently.
        modular_list.sort(key=lambda k: sort_key(k['title']))

        directory.builder(modular_list, content='videos', add_all_at_once=True)
