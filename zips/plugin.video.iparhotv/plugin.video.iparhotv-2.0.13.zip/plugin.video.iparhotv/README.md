# IPARHO TV Kodi add-on

Greek live TV, movies, series and kids content. Rebuilt on the AliveGR 3.x
codebase (GPL-3.0-only, author Twilight0) with IPARHO branding and sections.

Install from the ElaRepo repository: https://repo.elarepo.org/
