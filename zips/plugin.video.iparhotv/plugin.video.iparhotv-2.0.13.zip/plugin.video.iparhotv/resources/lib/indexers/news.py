# -*- coding: utf-8 -*-

# IPARHO TV Addon
# SPDX-License-Identifier: GPL-3.0-only
# See LICENSES/GPL-3.0-only for more information.
from tulip import kodi
from netclient import Net as net_client
from tulip.init import syshandle, sysaddon
from tulip.cleantitle import replaceHTMLCodes
from itertags import iwrapper
from ..modules.themes import iconname
from ..modules.constants import cache_method, cache_duration


class Indexer:

    def __init__(self):

        self.list = []; self.data = []; self.directory = []
        self.fp_link = 'http://www.frontpages.gr'

    @staticmethod
    def switcher():

        def seq(choose):

            kodi.setSetting('papers_group', choose)
            kodi.idle()
            kodi.sleep(100)
            kodi.refresh()

        groups = (
            [kodi.i18n(30231), kodi.i18n(30232), kodi.i18n(30233), kodi.i18n(30234)],
            ['0', '1', '2', '3']
        )

        choice = kodi.selectDialog(heading=kodi.i18n(30049), list=groups[0])

        if choice <= len(groups[0]) and not choice == -1:
            seq(groups[1][choice])
        else:
            kodi.execute('Dialog.Close(all)')

    @cache_method(cache_duration(720))
    def front_pages(self):

        html = net_client().http_GET(self.fp_link).content

        try:
            html = html.decode('utf-8')
        except (UnicodeDecodeError, AttributeError):
            pass

        groups = [tab.text for tab in iwrapper(html, 'div', attrs={'class': 'tabbertab.+?'})]

        for group, papers in list(enumerate(groups)):

            items = [thumb.text for thumb in iwrapper(papers, 'div', attrs={'class': 'thumber'})]

            for i in items:

                title = next(iwrapper(i, 'img', attrs={'style': 'padding:5px.+?'}, ret='alt'))
                title = replaceHTMLCodes(title)
                image = next(iwrapper(i, 'img', attrs={'style': 'padding:5px.+?'}, ret='src'))
                image = ''.join([self.fp_link, image])
                link = image.replace('300.jpg', 'I.jpg')

                data = {'title': title, 'image': image, 'url': link, 'group': group}

                self.list.append(data)

        return self.list

    def papers_index(self):

        self.data = self.front_pages()

        for i in self.data:
            i.update({'action': None, 'isFolder': 'False'})

        try:
            self.list = [item for item in self.data if item['group'] == int(kodi.setting('papers_group'))]
        except Exception:
            self.list = [item for item in self.data if item['group'] == 0]
            kodi.setSetting('papers_group', '0')

        if kodi.setting('papers_group') == '1':
            integer = 30232
        elif kodi.setting('papers_group') == '2':
            integer = 30233
        elif kodi.setting('papers_group') == '3':
            integer = 30234
        else:
            integer = 30231

        switch = {
            'title': kodi.i18n(30047).format(kodi.i18n(integer)),
            'icon': iconname('switcher'),
            'action': 'papers_switcher'
        }

        if kodi.setting('show_pic_switcher') == 'true':

            li = kodi.item(label=switch['title'])
            li.setArt({'icon': switch['icon'],'fanart': kodi.addonInfo('fanart')})
            url = '{0}?action={1}'.format(sysaddon, switch['action'])
            kodi.addItem(syshandle, url, li)

        for i in self.list:

            li = kodi.item(label=i['title'])
            li.setArt({'icon': i['image'], 'poster': i['image'], 'thumb': i['image'], 'fanart': kodi.addonInfo('fanart')})
            li.setInfo('image', {'title': i['title'], 'picturepath': i['url']})
            url = i['url']
            self.directory.append((url, li, False))

        kodi.addItems(syshandle, self.directory)
        kodi.directory(syshandle)
