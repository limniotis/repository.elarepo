# -*- coding: utf-8 -*-

# IPARHO TV Addon
# SPDX-License-Identifier: GPL-3.0-only
# See LICENSES/GPL-3.0-only for more information.

from tulip import kodi, directory
from tulip.init import syshandle
from ..modules.themes import iconname
from ..modules.constants import ART_ID


class Indexer:

    def __init__(self):

        self.list = []; self.data = []

    def sports(self):

        self.list = [
            {
                'title': 30950,
                'action': 'sports_news',
                'icon': iconname('news')
            }
            ,
            {
                'title': 30951,
                'action': 'gm_sports',
                'icon': iconname('sports')
            }
            ]

        directory.builder(self.list)

    def sports_news(self):

        self.data = [
            {
                'title': 'ERTflix Sports',
                'icon': kodi.addonmedia(addonid=ART_ID, theme='networks', path='ert_icon.png', media_subfolder=False),
                'url': 'plugin://plugin.video.ert.gr/?action=categories&url=https%3a%2f%2fwww.ertflix.gr%2fshow%2fsport',
                'fanart': kodi.addonmedia(addonid=ART_ID, theme='networks', path='ert_fanart.jpg', media_subfolder=False)
            }
            # ,
            # {
            #     'title': 'Ant1 Sports',
            #     'icon': kodi.addonmedia(addonid=ART_ID, theme='networks', path='ant1_icon.png', media_subfolder=False),
            #     'url': 'plugin://plugin.video.antenna.gr/?action=videos&url=https%3a%2f%2fwww.antenna.gr%2fwebtv%2f3062%2fathlitika%3fshowall',
            #     'fanart': kodi.addonmedia(addonid=ART_ID, theme='networks', path='ant1_fanart.jpg', media_subfolder=False)
            # }
            ,
            {
                'title': 'Alpha Sports',
                'icon': kodi.addonmedia(addonid=ART_ID, theme='networks', path='alpha_icon.png', media_subfolder=False),
                'url': 'plugin://plugin.video.alphatv.gr/?action=news_episodes&query=19&title=%ce%91%ce%b8%ce%bb%ce%b7%cf%84%ce%b9%ce%ba%ce%b1',
                'fanart': kodi.addonmedia(addonid=ART_ID, theme='networks', path='alpha_fanart.jpg', media_subfolder=False)
            }
            # ,
            # {
            #     'title': 'NovaSports',
            #     'icon': kodi.addonmedia(addonid=ART_ID, theme='networks', path='nova_icon.png', media_subfolder=False),
            #     'url': 'plugin://plugin.video.novasports.gr/',
            #     'fanart': kodi.addonmedia(addonid=ART_ID, theme='networks', path='nova_fanart.jpg', media_subfolder=False)
            # }
        ]

        for item in self.data:

            list_item = kodi.item(label=item['title'])
            list_item.setArt({'icon': item['icon'], 'fanart': item['fanart']})
            _url_ = item['url']
            isFolder = True

            self.list.append((_url_, list_item, isFolder))

        kodi.addItems(syshandle, self.list)
        kodi.directory(syshandle)
