# -*- coding: utf-8 -*-

# IPARHO TV Addon
# SPDX-License-Identifier: GPL-3.0-only
# See LICENSES/GPL-3.0-only for more information.
from tulip import kodi, directory
from ..modules.constants import ART_ID
from ..modules.themes import iconname


class Indexer:

    def __init__(self):

        self.addons = [
            {
                'title': 'E-RADIO ADDON',
                # ponytail: the logos add-on ships no ERADIO.png (and no 'logos' theme dir),
                # so the original path resolved to a missing file. Uses the themed radios icon.
                'image': iconname('radios'),
                'url': 'plugin.audio.eradio.gr'
            }
            ,
            {
                'title': 'EPT PLAYER RADIO STATIONS',
                'image': kodi.addonmedia(addonid=ART_ID, theme='networks', path='ert_fanart.jpg', media_subfolder=False),
                'url': 'plugin://plugin.video.ert.gr/?action=radios'
            }
            ,
            {
                'title': 'SOMAFM ADDON',
                'image': 'https://alivegr.net/logos/SOMAFM.png',
                'url': 'plugin.audio.somafm.com'
            }
        ]

    def radio(self):

        for addon in self.addons:
            addon.update({'action': 'activate_other_addon', 'isFolder': 'False', 'isPlayable': 'False', 'query': 'audio'})

        directory.builder(self.addons)
