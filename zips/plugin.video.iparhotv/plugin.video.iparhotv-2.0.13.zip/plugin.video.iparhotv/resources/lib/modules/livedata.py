# -*- coding: utf-8 -*-

# IPARHO TV Addon
# SPDX-License-Identifier: GPL-3.0-only
# See LICENSES/GPL-3.0-only for more information.

"""
The Live TV list, minus Kodi.

Everything that decides what the list contains and how long a fetch may take lives here, with
no Kodi import, so it runs and is tested under plain Python. live.py keeps only the Kodi glue:
settings, strings, the directory builder.

Latency budget, cold cache, for the user on a blocked or slow connection:

  before 2.0.8   JSON tier 1 (20 s) -> JSON tier 2 (20 s) -> M3U tier 1 (20 s) -> M3U tier 2 (20 s)
                 = up to 80 s, then the same again on the next open if it all failed.
  2.0.8          JSON and M3U chains run side by side; the website tier gets PRIMARY_TIMEOUT,
                 only the upstream fallback keeps the full 20 s; and a failure serves the last
                 good list at once and is not retried for RETRY_AFTER seconds.
"""

import json
import os
import re
import threading
import time
import unicodedata

# The website copy is the primary source and normally answers in well under a second; when
# it does not answer at all (ISP block, outage) the point is to move on fast. The upstream
# fallback keeps netclient's default, since it is the last chance and may be far away.
PRIMARY_TIMEOUT = 8
FALLBACK_TIMEOUT = 20

# After a total failure the last good list is served without touching the network for this
# long, so a blocked host costs one slow open, not one slow open per click.
RETRY_AFTER = 600

# Only a failure that took this long earns the backoff. A fetch that fails at once (no network
# yet at boot, DNS not answering, connection refused) is cheap to retry on the next open, and
# backing off from it would keep showing the offline copy for ten minutes after the network
# came up.
SLOW_FAILURE = 3

LAST_GOOD_FILE = 'live_last_good.json'
# The backoff marker is a separate few-byte file, so deciding whether to retry never means
# parsing the whole saved list.
FAILURE_MARKER = 'live_last_good.failed'

# The playlist chain may run up to PRIMARY + FALLBACK on its own; the wait for it is allowed
# that plus a little, since netclient's timeouts are per socket operation, not per request.
WAIT_GRACE = 2


class Background:

    """
    A function run on a daemon thread, with a bounded wait for its result.

    Used for the playlist fetch while the JSON list is fetched on the calling thread. A daemon
    thread on purpose: if the caller gives up waiting, or raises, the worker must not keep the
    plugin invocation alive until a blocked host times out. concurrent.futures workers are
    non-daemon and are joined at interpreter shutdown, which is exactly the wait to avoid.
    """

    def __init__(self, function, *args):

        self.result_value = None
        self.error = None
        self.done = threading.Event()
        self.thread = threading.Thread(target=self._run, args=(function,) + args, daemon=True)
        self.thread.start()

    def _run(self, function, *args):

        try:
            self.result_value = function(*args)
        except BaseException as error:  # noqa: B902 - handed back to the waiter, never lost
            self.error = error
        finally:
            self.done.set()

    def result(self, timeout=None):
        """The function's return value; re-raises its exception; TimeoutError when not done."""

        if not self.done.wait(timeout):
            raise TimeoutError('still running after {0} s'.format(timeout))

        if self.error is not None:
            raise self.error

        return self.result_value


def channel_key(title):

    """
    Normalised channel title, used only to spot the same channel in both lists.

    Deliberately blunt: case, spacing, punctuation and a trailing HD are all noise when the two
    lists are maintained by different people, so 'ERT1 HD' and 'ERT 1' collapse together. Going
    finer than this risks folding two genuinely different regional channels into one, which is
    worse than showing a duplicate.
    """

    key = ''.join(c for c in title.lower() if c.isalnum())

    return key[:-2] if key.endswith('hd') else key


def sort_key(title):

    """
    Alphabetical key for a channel title.

    Accents and case are folded first: by code point an accented Greek capital sorts away from
    its plain form (Ό lands after ω), and 'ERT' and 'ert' would split. Latin names still come
    before Greek ones, which is the convention the lists themselves follow.
    """

    folded = unicodedata.normalize('NFD', title)

    return ''.join(c for c in folded if unicodedata.category(c) != 'Mn').casefold()


def is_playlist(result):

    if '#EXTM3U' not in result:
        raise ValueError('not a playlist')


def parse_channels(result):
    """The JSON list body -> the parsed document; tolerates the single-quoted variant."""

    try:
        return json.loads(result)
    except ValueError:
        return json.loads(result.replace('\'', '"'))


def fetch_chain(fetch, urls, validate, timeouts=None):

    """
    Return the body of the first url that both answers and passes validate().

    fetch(url, timeout) does the request; every tier is validated rather than merely fetched,
    because a host that answers 200 with a holding page would otherwise be served as though it
    were the channel list. The first tier is the website copy and gets PRIMARY_TIMEOUT; the
    rest keep FALLBACK_TIMEOUT. If no tier survives, the last exception propagates, so a total
    outage is never cached as an empty list.
    """

    if timeouts is None:
        timeouts = [PRIMARY_TIMEOUT] + [FALLBACK_TIMEOUT] * (len(urls) - 1)

    last = len(urls) - 1

    for index, (url, timeout) in enumerate(zip(urls, timeouts)):

        try:
            result = fetch(url, timeout)
            validate(result)
            return result
        except Exception:
            if index == last:
                raise


_M3U_ENTRY = re.compile(r'#EXTINF:.+?\n.+?$', re.M)
_M3U_TITLE = re.compile(r',(.+)')
# Non-greedy: a playlist that puts another attribute after tvg-logo would otherwise capture
# through to the last quote.
_M3U_LOGO = re.compile(r'tvg-logo="(.+?)"')
_M3U_GROUP = re.compile(r'group-title="(.+?)"')
_M3U_URL = re.compile(r'\n(.+)')


def parse_m3u(result, default_image):

    m3u_list = []

    for item in _M3U_ENTRY.findall(result):

        # .strip(): the playlist carries trailing spaces on some names ('ERT WORLD '),
        # which showed in the label and stopped the pinned-channel match from finding them.
        title = _M3U_TITLE.search(item).group(1).strip()
        logo = _M3U_LOGO.search(item)
        image = logo.group(1) if logo else default_image
        group = _M3U_GROUP.search(item)
        group = group.group(1) if group else ''
        url = _M3U_URL.search(item).group(1)

        m3u_list.append({'title': title, 'image': image, 'group': group, 'url': url})

    return m3u_list


def merge_m3u(live_list, m3u_list, live_groups, m3u_groups, genre_names, year):

    """
    Fold the M3U playlist into the JSON channel list.

    Channels already in the JSON list are skipped and the JSON entry wins, since it carries
    the info, website, headers and DRM fields that the playlist format cannot express.

    Two playlists, two labelling conventions: komhsgr's uses Greek uppercase names (mapped by
    m3u_groups), elarepo's uses the English live_groups keys directly. So translate through
    m3u_groups if the label is Greek, otherwise fall back to the raw label as a live_groups
    key, and only then to Web TV. Without the passthrough every one of elarepo's 227 channels
    collapsed into Web TV.

    genre_names is the group -> localised name map built once per list; the old code asked
    Kodi for the same nine strings once per channel.
    """

    seen = {channel_key(item['title']) for item in live_list}
    web_tv = live_groups['Web TV']

    for item in m3u_list:

        key = channel_key(item['title'])

        if not key or key in seen:
            continue

        seen.add(key)
        raw = item['group']
        group = live_groups.get(m3u_groups.get(raw, raw), web_tv)

        live_list.append(
            {
                'title': item['title'], 'image': item['image'], 'group': str(group),
                'genre': genre_names[group], 'plot': '', 'website': 'None',
                'year': year, 'url': item['url']
            }
        )

    return live_list


class LastGood:

    """
    The last list that was built successfully, kept beside the function cache with no expiry.

    The function cache expires after eight hours and is wiped on every update, and a fetch
    that fails is deliberately never cached. Before 2.0.8 that meant a blocked host was paid
    for in full on every open, ending in an error. Now the last good list is served instead,
    and the network is left alone for RETRY_AFTER seconds after a failure.

    An empty list is never persisted: serving nothing forever would be worse than an error.
    """

    def __init__(self, directory, now=time.time):

        self.path = os.path.join(directory, LAST_GOOD_FILE)
        self.marker = os.path.join(directory, FAILURE_MARKER)
        self.now = now

    def _write(self, payload):
        """
        Atomic replace through a private temporary name: two plugin invocations building the
        list at the same time (a group switch racing a refresh) each write their own file and
        the last rename wins whole, never a torn or half-written one.
        """

        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        temp = '{0}.{1}.{2}.tmp'.format(self.path, os.getpid(), threading.get_ident())

        try:
            with open(temp, 'w', encoding='utf-8') as handle:
                json.dump(payload, handle)
            os.replace(temp, self.path)
        finally:
            try:
                os.remove(temp)
            except OSError:
                pass

    def save(self, live_list, updated, m3u_list):
        """
        Keep a good list. Returns False when it could not be written (a full or read-only
        profile): persisting is a convenience, and a list that was fetched fine must be
        served regardless, so nothing here raises.
        """

        if not live_list:
            return False

        payload = {'saved_at': self.now(), 'updated': updated, 'list': live_list, 'm3u': m3u_list or []}

        try:
            self._write(payload)
        except (OSError, TypeError, ValueError):
            return False

        self.clear_failure()

        return True

    def load(self):
        """The saved payload, or None when there is none or it is unreadable."""

        try:
            with open(self.path, encoding='utf-8') as handle:
                payload = json.load(handle)
        except (OSError, ValueError):
            return None

        if not isinstance(payload, dict) or not payload.get('list'):
            return None

        return payload

    def note_failure(self):
        """Start the backoff, but only when there is a saved list to serve meanwhile."""

        if self.load() is None:
            return

        try:
            with open(self.marker, 'w', encoding='utf-8') as handle:
                handle.write(repr(self.now()))
        except OSError:
            pass

    def clear_failure(self):
        """Forget the backoff, keep the list: what an explicit cache clear or refresh means."""

        try:
            os.remove(self.marker)
        except OSError:
            pass

    def failed_recently(self, within=None):

        if within is None:
            within = RETRY_AFTER

        try:
            with open(self.marker, encoding='utf-8') as handle:
                failed_at = float(handle.read().strip())
        except (OSError, ValueError):
            return False

        return 0 <= self.now() - failed_at < within

    def clear(self):

        for name in (self.path, self.marker):
            try:
                os.remove(name)
            except OSError:
                pass
