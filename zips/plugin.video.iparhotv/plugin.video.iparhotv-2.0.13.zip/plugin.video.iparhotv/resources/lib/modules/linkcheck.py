# -*- coding: utf-8 -*-

# IPARHO TV Addon
# SPDX-License-Identifier: GPL-3.0-only
# See LICENSES/GPL-3.0-only for more information.

"""
The link checker behind the "Auto" source choice.

A resolved stream is probed with a one-byte ranged GET before it is handed to Kodi, so a dead
source (a 404 "file was deleted" page, an HTML placeholder served with 200, a host that no
longer answers) is skipped and the next one is tried, instead of Kodi opening a broken link.

Kept free of any Kodi import so it runs, and is tested, under plain Python.
"""

import json
import socket
import ssl
import urllib.error
import urllib.request
from urllib.parse import parse_qsl

# One probe must never stall the sequential check for long: a host the ISP blocks at IP/SNI
# level answers nothing at all, and only the timeout moves the check on to the next source.
PROBE_TIMEOUT = 8

DEFAULT_USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Safari/537.36'
)

# Request headers a resolver may append after '|' that the real playback request would carry
# too, so the probe must carry them as well or a token-protected CDN would reject it.
_FORWARDED_HEADERS = ('user-agent', 'referer', 'origin', 'cookie', 'authorization')


def split_headers(stream):
    """'url|User-Agent=x&Referer=y' -> ('url', {'User-Agent': 'x', 'Referer': 'y'})."""

    if not stream or '|' not in stream:
        return stream, {}

    url, _, query = stream.rpartition('|')

    return url, dict(parse_qsl(query))


# A URL whose path is a streaming manifest or a transport stream is played as is by Kodi or
# inputstream.adaptive;
# no ResolveURL resolver turns such a URL into anything else, so offering it to the resolver
# scan on every live channel click only costs time. Media-file suffixes (.mp4 and friends)
# are deliberately NOT here: hoster embed pages carry a file name in their path
# (streamtape-style /e/<id>/<name>.mp4) and those must still be resolved.
DIRECT_STREAM_SUFFIXES = ('.m3u8', '.m3u', '.mpd', '.ism', '.isml', '.ts')
LOCAL_PROXY_PREFIXES = ('http://127.0.0.1:', 'http://localhost:')


def is_direct_stream(stream):
    """
    True for a URL that needs no resolving: a streaming manifest by path suffix, or the
    add-on's own local proxy. Query strings and a '|headers' suffix are ignored for the
    decision. Everything else, page URLs included, returns False so the resolvers get it.
    """

    if not stream:
        return False

    url, _ = split_headers(stream)
    lowered = url.lower()

    if lowered.startswith(LOCAL_PROXY_PREFIXES):
        return True

    if not lowered.startswith(('http://', 'https://')):
        return False

    path = lowered.split('?', 1)[0].split('#', 1)[0]

    return path.endswith(DIRECT_STREAM_SUFFIXES)


def drm_from_header(value):
    """
    The DRM header a live channel carries, as (licence_type, licence_key), or None.

    live.py stores json.dumps([licence_type, licence_key]) in the '|' headers; after the
    urlencode/parse_qsl round trip it is that JSON text again. The old player read drm[0]
    and drm[1] straight off the text, which yielded '[' and '"\""'. The licence key goes to
    inputstream.adaptive.license_key, which takes its own 'url|headers|post|response' text,
    so a string is passed through untouched; anything structured is JSON-encoded, as before.
    """

    if value is None:
        return None

    drm = value

    if isinstance(drm, str):
        try:
            drm = json.loads(drm)
        except ValueError:
            return None

    if isinstance(drm, dict):
        # {"type": ..., "key": ...} is the other shape the admin tool could emit.
        drm = [drm.get('type') or drm.get('licence_type'), drm.get('key') or drm.get('licence_key')]

    if not isinstance(drm, (list, tuple)) or len(drm) < 2 or not drm[0]:
        return None

    key = drm[1] if isinstance(drm[1], str) else json.dumps(drm[1])

    return str(drm[0]), key


def _is_html(content_type):

    return (content_type or '').strip().lower().startswith('text/html')


def _probe(url, headers, timeout, context=None):
    """Returns (status, content_type); raises on connection failure."""

    request = urllib.request.Request(url, headers=headers, method='GET')

    try:
        with urllib.request.urlopen(request, timeout=timeout, context=context) as response:
            return response.status, response.headers.get('Content-Type', '')
    except urllib.error.HTTPError as error:
        return error.code, error.headers.get('Content-Type', '')


def is_playable(stream, timeout=PROBE_TIMEOUT):
    """
    True when the stream answers a ranged GET with a non-HTML success (2xx, or 416 for a file
    too small for the range, which still proves it exists). False for a 4xx/5xx, an HTML body,
    a refused connection, a TLS failure or a timeout - all of which mean: skip to the next
    source. Anything that is not an http(s) URL (plugin://, rtmp://, local paths) is handed to
    Kodi unprobed.
    """

    if not stream:
        return False

    url, extra = split_headers(stream)

    if not url.lower().startswith(('http://', 'https://')):
        return True

    headers = {'Range': 'bytes=0-0', 'User-Agent': DEFAULT_USER_AGENT}

    for key, value in extra.items():
        if key.lower() in _FORWARDED_HEADERS and value:
            headers[key] = value

    try:
        try:
            status, content_type = _probe(url, headers, timeout)
        except urllib.error.URLError as error:
            # Kodi's bundled Python on some devices ships without a usable CA bundle. The probe
            # is a liveness check, not the playback request, so verification failing must not
            # condemn every https source: retry once without it.
            if not isinstance(error.reason, ssl.SSLCertVerificationError):
                raise
            status, content_type = _probe(url, headers, timeout, context=ssl._create_unverified_context())
    except (urllib.error.URLError, socket.timeout, ssl.SSLError, ConnectionError, OSError, ValueError):
        return False

    if status == 416:
        return not _is_html(content_type)

    return 200 <= status < 300 and not _is_html(content_type)
