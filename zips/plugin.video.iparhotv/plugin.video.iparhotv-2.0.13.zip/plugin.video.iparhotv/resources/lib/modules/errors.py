# -*- coding: utf-8 -*-

# IPARHO TV Addon
# SPDX-License-Identifier: GPL-3.0-only
# See LICENSES/GPL-3.0-only for more information.


class SiteUnavailable(Exception):
    """greek-movies.com could not be fetched, or did not return a usable page.

    This is raised - never swallowed - from inside the cached fetchers on
    purpose. An exception bypasses pickled.FunctionCache, so a site that is
    blocked by the ISP, changed its markup or is simply down is never stored
    as an empty result and served back for the next twelve hours. The router
    catches exactly this type and turns it into a single notification plus a
    clean empty directory, instead of the generic red X Kodi paints for any
    unhandled exception.

    It is kept in its own dependency-free module so router.py can import it
    without paying for the indexer imports it otherwise defers.
    """

    def __init__(self, url='', reason='network'):
        # 'network': the site could not be fetched (block, outage, SSL) - the notice
        # suggests a VPN. 'structure': it answered, but not with the page expected -
        # a changed site or a non-page - so a VPN would be the wrong advice.
        self.url = url
        self.reason = reason
        super().__init__(url)
