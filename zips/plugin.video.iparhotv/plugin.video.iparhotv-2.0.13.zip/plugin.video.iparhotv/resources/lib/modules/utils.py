# -*- coding: utf-8 -*-

# AliveGR Addon
# Author Twilight0
# SPDX-License-Identifier: GPL-3.0-only
# See LICENSES/GPL-3.0-only for more information.

from os import rename
from xbmcaddon import Addon
import pickled
import sqlite3
from itertags import iwrapper
from tulip import kodi, directory, cleantitle
from netclient import Net
from urllib.parse import parse_qsl, urlparse
from tulip.log import log
from .themes import iconname
from .constants import WEBSITE, PINNED, SEARCH_HISTORY, PLAYBACK_HISTORY, cache_duration
from .livedata import LastGood
from tulip.kodi import update_repositories
from os import path
from time import time
from base64 import b64decode


########################################################################################################################

reset_cache = pickled.FunctionCache(kodi.cacheDirectory).reset_cache
cache_function = pickled.FunctionCache(kodi.cacheDirectory).cache_function


def stream_picker(links):

    _choice = kodi.selectDialog(heading=kodi.i18n(30006), list=[link[0] for link in links])

    if _choice != -1:
        return links[_choice][1]


def i18n():

    lang = 'el_GR' if 'Greek' in kodi.infoLabel('System.Language') else 'en_GB'

    return lang


def reset_idx(notify=True, forceit=False):

    if Addon().getSetting('reset_idx') == 'true' or forceit:

        if Addon().getSetting('reset_live') == 'true' or forceit:

            kodi.setSetting('live_group', '0')

        kodi.setSetting('vod_group', '30213')

        if notify:
            kodi.infoDialog(message=kodi.i18n(30402), time=3000)

        log('Indexers have been reset')


def activate_other_addon(url, query=None):

    if not url.startswith('plugin://'):
        url = ''.join(['plugin://', url, '/'])

    parsed = urlparse(url)

    if not kodi.condVisibility('System.HasAddon({0})'.format(parsed.netloc)):
        kodi.execute('InstallAddon({0})'.format(parsed.netloc))

    params = dict(parse_qsl(parsed.query))
    action = params.get('action')
    url = params.get('url')

    directory.run_builtin(addon_id=parsed.netloc, action=action, url=url, content_type=query)


def cache_clear():

    log('Cache has been cleared')
    reset_cache()
    # The last good Live TV list is kept (it is what makes a cleared cache still open Live TV
    # when the host is down), but an explicit clear means "try the network now": the backoff
    # from a recent failure is dropped.
    LastGood(kodi.dataPath).clear_failure()


def purge_bookmarks():

    if path.exists(kodi.bookmarksFile):
        if kodi.yesnoDialog(line1=kodi.i18n(30214)):
            kodi.deleteFile(kodi.bookmarksFile)
            kodi.infoDialog(kodi.i18n(30402))
            kodi.refresh()
        else:
            kodi.infoDialog(kodi.i18n(30403))
    else:
        kodi.infoDialog(kodi.i18n(30139))


def clear_history(file_):

    if path.exists(file_):
        if kodi.yesnoDialog(line1=kodi.i18n(30484).format(path.basename(file_))):
            kodi.deleteFile(file_)
            kodi.infoDialog(kodi.i18n(30402))
            kodi.refresh()
        else:
            kodi.infoDialog(kodi.i18n(30403))
    else:
        kodi.infoDialog(kodi.i18n(30347))


def clear_search_history():

    clear_history(SEARCH_HISTORY)


def clear_playback_history():

    clear_history(PLAYBACK_HISTORY)


def tools_menu():

    kodi.execute('Dialog.Close(all)')

    kodi.execute('ActivateWindow(programs,"plugin://plugin.video.iparhotv/?content_type=executable",return)')


def call_info():

    kodi.close_all()

    kodi.execute('ActivateWindow(programs,"plugin://plugin.video.iparhotv/?content_type=executable&action=info",return)')


def refresh_and_clear():

    cache_clear()
    kodi.sleep(100)
    kodi.refresh()


def thgiliwt(s):

    string = s[::-1]

    return b64decode(string)


def pin_to_file(file_, txt):

    if not kodi.exists(file_):
        kodi.makeFiles(kodi.dataPath)

    if not txt:
        return

    if txt not in pinned_from_file(file_):

        with open(file_, 'a') as f:
            f.writelines(txt + '\n')


def pinned_from_file(file_):

    if kodi.exists(file_):

        with open(file_, 'r') as f:
            text = [i.rstrip('\n') for i in f.readlines()][::-1]

        return text

    else:

        return ['']


def unpin_from_file(file_, txt):

    with open(file_, 'r') as f:
        text = [i.rstrip('\n') for i in f.readlines()]

    text.remove(txt)

    with open(file_, 'w') as f:
        if not text:
            text = ''
        else:
            text = '\n'.join(text) + '\n'
        f.write(text)


def pin(query):

    kodi.busy()

    pin_to_file(PINNED, query)

    kodi.infoDialog(kodi.i18n(30338), time=750)

    kodi.idle()


def unpin(query):

    kodi.busy()

    unpin_from_file(PINNED, query)

    kodi.sleep(100)
    kodi.refresh()

    kodi.infoDialog(kodi.i18n(30338), time=750)

    kodi.idle()


def setup_iptv():

    """
    Add every live channel to Kodi's native TV/PVR guide through pvr.iptvsimple.

    A local M3U is written from the live list - each channel plays back through the plugin,
    so the header/DRM/resolver path in player.py is reused - and pvr.iptvsimple is pointed at
    it. On Kodi 20+ pvr.iptvsimple keeps its M3U location in per-instance settings that cannot
    be written from another add-on, so setSetting is best effort and the file path is shown for
    a one-time manual pointer if the channels do not appear.

    ponytail: no EPG is configured - there is no XMLTV source - so channels show without a
    programme guide. Add an epgPath here if a guide source ever exists.
    """

    from resources.lib.indexers.live import Indexer

    if not path.exists(kodi.dataPath):
        kodi.makeFile(kodi.dataPath)

    m3u_path = kodi.join(kodi.dataPath, 'iparho_live.m3u')

    try:
        text = Indexer().iptv_m3u_text()
    except Exception:
        # Same notice the directory listings use when the live list cannot be fetched.
        kodi.infoDialog(kodi.i18n(30958))
        return

    with open(m3u_path, 'w', encoding='utf-8') as m3u_file:
        m3u_file.write(text)

    try:
        enabled = kodi.addon_details('pvr.iptvsimple').get('enabled')
    except Exception:
        enabled = None

    if not enabled:

        home_path = kodi.transPath(kodi.join('special://home', 'addons', 'pvr.iptvsimple'))
        xbmc_path = kodi.transPath(kodi.join('special://xbmc', 'addons', 'pvr.iptvsimple'))

        if path.exists(home_path) or path.exists(xbmc_path):
            kodi.enable_addon('pvr.iptvsimple')
        else:
            kodi.execute('InstallAddon(pvr.iptvsimple)')
            kodi.okDialog(heading=kodi.addonInfo('name'), line1=kodi.i18n(30964))
            return

    # Best effort: works where pvr.iptvsimple keeps flat settings (Kodi <= 19); a no-op on the
    # per-instance settings of Kodi 20+, where the dialog below tells the user the path to set.
    try:
        ipsc = Addon('pvr.iptvsimple')
        ipsc.setSetting('m3uPathType', '0')  # 0 = local path
        ipsc.setSetting('m3uPath', m3u_path)
    except Exception:
        pass

    kodi.enable_addon('pvr.iptvsimple')

    try:
        kodi.set_gui_setting('pvrmanager.enabled', True)
    except Exception:
        pass

    kodi.okDialog(heading=kodi.addonInfo('name'), line1=kodi.i18n(30963).format(m3u_path))


def setup_various_keymaps(keymap):

    keymap_settings_folder = kodi.transPath('special://profile/keymaps')

    if not path.exists(keymap_settings_folder):
        kodi.makeFile(keymap_settings_folder)

    if keymap == 'previous':

        location = kodi.join(keymap_settings_folder, 'alivegr_tvguide.xml')

        lang_int = 30022

        def seq():

            previous_keymap = """<keymap>
    <tvguide>
        <keyboard>
            <key id="61448">previousmenu</key>
        </keyboard>
    </tvguide>
    <tvchannels>
        <keyboard>
            <key id="61448">previousmenu</key>
        </keyboard>
    </tvchannels>
</keymap>
"""

            with open(location, 'w') as f:
                f.write(previous_keymap)

    elif keymap == 'mouse':

        location = kodi.transPath(kodi.join('special://profile', 'keymaps', 'alivegr_mouse.xml'))

        lang_int = 30238

        def seq():

            string_start = '<keymap><slideshow><mouse>'
            string_end = '</mouse></slideshow></keymap>'
            string_for_left = '<leftclick>NextPicture</leftclick>'
            string_for_right = '<rightclick>PreviousPicture</rightclick>'
            string_for_middle = '<middleclick>Rotate</middleclick>'
            string_for_up = '<wheelup>ZoomIn</wheelup>'
            string_for_down = '<wheeldown>ZoomOut</wheeldown>'

            classes = [
                string_for_left, string_for_right, string_for_middle,
                string_for_up, string_for_down
            ]

            map_left = kodi.i18n(30241)
            map_right = kodi.i18n(30242)
            map_middle = kodi.i18n(30243)
            map_up = kodi.i18n(30244)
            map_down = kodi.i18n(30245)

            keys = [
                map_left, map_right, map_middle, map_up, map_down
            ]

            kodi.okDialog(kodi.name(), kodi.i18n(30240))

            indices = kodi.dialog.multiselect(kodi.name(), keys)

            if not indices:

                kodi.infoDialog(kodi.i18n(30246))

            else:

                finalized = []

                for i in indices:
                    finalized.append(classes[i])

                joined = ''.join(finalized)

                to_write = string_start + joined + string_end

                with open(location, 'w') as f:
                    f.write(to_write)

                kodi.execute('Action(reloadkeymaps)')

    elif keymap == 'samsung':

        string = '''<keymap>
    <global>
        <keyboard>
            <key id="61670">contextmenu</key>
        </keyboard>
    </global>
    <fullscreenvideo>
        <keyboard>
            <key id="61670">osd</key>
        </keyboard>
    </fullscreenvideo>
    <visualisation>
        <keyboard>
            <key id="61670">osd</key>
        </keyboard>
    </visualisation>
</keymap>'''

        location = kodi.join(keymap_settings_folder, 'samsung.xml')

        lang_int = 30022

        def seq():

            with open(location, 'w') as f:
                f.write(string)

    elif keymap == 'stop_playback':

        string = '''<keymap>
    <fullscreenvideo>
        <keyboard>
            <key id="61448">stop</key>
        </keyboard>
        <keyboard>
            <key id="61448" mod="longpress">back</key>
        </keyboard>
    </fullscreenvideo>
    <visualisation>
        <keyboard>
            <key id="61448">stop</key>
        </keyboard>
        <keyboard>
            <key id="61448" mod="longpress">back</key>
        </keyboard>
    </visualisation>
</keymap>'''

        location = kodi.join(keymap_settings_folder, 'stop_playback.xml')

        lang_int = 30022

        def seq():

            with open(location, 'w') as f:
                f.write(string)

    yes = kodi.yesnoDialog(kodi.i18n(lang_int))

    if yes:

        if path.exists(location):

            choices = [kodi.i18n(30248), kodi.i18n(30249)]

            _choice = kodi.selectDialog(choices, heading=kodi.i18n(30247))

            if _choice == 0:

                seq()
                kodi.okDialog(kodi.name(), kodi.i18n(30027) + ', ' + (kodi.i18n(30028)))
                kodi.infoDialog(kodi.i18n(30402))
                kodi.execute('Action(reloadkeymaps)')

            elif _choice == 1:

                kodi.deleteFile(location)
                kodi.infoDialog(kodi.i18n(30402))
                kodi.execute('Action(reloadkeymaps)')

            else:

                kodi.infoDialog(kodi.i18n(30403))

        else:

            seq()
            kodi.okDialog(kodi.name(), kodi.i18n(30027) + ', ' + (kodi.i18n(30028)))
            kodi.infoDialog(kodi.i18n(30402))

            kodi.execute('Action(reloadkeymaps)')

    else:

        kodi.infoDialog(kodi.i18n(30403))


########################################################################################################################


def file_to_text(file_):

    with open(file_, encoding='utf-8', errors='replace') as text:
        return text.read()


def trim_content(f):

    history_size = int(Addon().getSetting('history_size'))

    with open(f, 'r', encoding='utf-8') as file_:
        lines = file_.readlines()

    if len(lines) > history_size:

        with open(f, 'w', encoding='utf-8') as file_:
            file_.writelines(lines[-history_size:])


def add_to_file(f, text, trim_file=True):

    if not text:
        return

    try:

        file_ = open(f, 'r', encoding='utf-8')
        if text + '\n' in file_.readlines():
            return
        file_.close()

    except IOError:
        log('File {0} does not exist, creating new...'.format(path.basename(f)))

    file_ = open(f, 'a', encoding='utf-8')

    file_.writelines(text + '\n')
    file_.close()
    if trim_file:
        trim_content(f=f)


def process_file(f, text, mode='remove'):

    file_ = open(f, 'r', encoding='utf-8')

    lines = file_.readlines()
    file_.close()

    if text + '\n' in lines:
        if mode == 'change':
            idx = lines.index(text + '\n')
            search_type, _, search_term = lines[idx].strip('\n').partition(',')
            str_input = kodi.inputDialog(heading=kodi.i18n(30445), default=search_term)
            if not str_input:
                return None
            str_input = cleantitle.strip_accents(str_input)
            lines[idx] = ','.join([search_type, str_input]) + '\n'
        else:
            lines.remove(text + '\n')
    else:
        return

    file_ = open(f, 'w', encoding='utf-8')
    file_.write(''.join(lines))
    file_.close()

    kodi.refresh()


def read_from_file(f):

    """
    Reads from history file which is stored in plain text, line by line
    :return: List
    """

    if kodi.exists(f):

        file_ = open(f, 'r', encoding='utf-8')
        text = [i.rstrip('\n') for i in file_.readlines()][::-1]

        file_.close()

        return text

    else:

        return


########################################################################################################################


def changelog(get_text=False):

    lang = Addon().getSetting('changelog_lang')
    greek = 'Greek' in kodi.infoLabel('System.Language')

    change_txt = 'changelog.en.txt' if lang == '1' or (lang == '0' and not greek) else 'changelog.el.txt'

    change_txt = kodi.join(kodi.addonPath, 'resources', 'texts', change_txt)

    if get_text:
        return file_to_text(change_txt).partition(u'\n\n')[0]
    else:
        kodi.dialog.textviewer(kodi.addonInfo('name') + ', ' + kodi.i18n(30110), file_to_text(change_txt))


def dmca():

    location = kodi.join(
        kodi.transPath(kodi.addonInfo('path')), 'resources', 'texts', 'dmca_{0}.txt'.format(i18n())
    )

    kodi.dialog.textviewer(kodi.addonInfo('name'), file_to_text(location))


def pp():

    location = kodi.join(
        kodi.transPath(kodi.addonInfo('path')), 'resources', 'texts', 'pp_{0}.txt'.format(i18n())
    )

    kodi.dialog.textviewer(kodi.addonInfo('name'), file_to_text(location))


def disclaimer():

    text = kodi.addonInfo('disclaimer')

    kodi.dialog.textviewer(kodi.addonInfo('name') + ', ' + kodi.i18n(30129), text)


def prompt():

    kodi.okDialog(kodi.addonInfo('name'), kodi.i18n(30356).format(version_text(remote_version())))

    choices = [kodi.i18n(30357), kodi.i18n(30358), kodi.i18n(30359)]

    _choice = kodi.selectDialog(choices, heading=kodi.i18n(30482))

    if _choice == 0:
        update_repositories()
    elif _choice == 1:
        kodi.close_all()
    elif _choice == 2:
        kodi.setSetting('new_version_prompt', 'false')
        kodi.okDialog(kodi.addonInfo('name'), kodi.i18n(30361))


def welcome():

    choices = [kodi.i18n(30329), kodi.i18n(30340), kodi.i18n(30129), kodi.i18n(30333)]

    _choice = kodi.selectDialog(choices, heading=kodi.i18n(30267).format(kodi.version()))

    if _choice in [0, -1]:
        kodi.close_all()
    elif _choice == 1:
        changelog()
    elif _choice == 2:
        disclaimer()
    elif _choice == 3:
        kodi.open_web_browser(WEBSITE)


def new_version(new=False):

    version_file = kodi.join(kodi.dataPath, 'version.txt')

    if not path.exists(version_file) or new:

        if not path.exists(kodi.dataPath):

            kodi.makeFile(kodi.dataPath)

        with open(version_file, mode='w', encoding='utf-8') as f:
            f.write(kodi.version())

        return True

    else:

        with open(version_file, encoding='utf-8') as f:
            version = f.read()

        if version != kodi.version():
            return new_version(new=True)
        else:
            return False


@cache_function(cache_duration(360))
def remote_version():

    url = 'https://raw.githubusercontent.com/limniotis/repository.elarepo/main/zips/addons.xml'
    # Bounded: this runs inside a plugin invocation, so when the host is slow or blocked the
    # user must not wait 20 s for a version check on top of everything else. Reads the same
    # git-served index the repository installs from, so the in-add-on prompt matches what
    # Kodi's repository updater will actually fetch.
    xml = Net().http_GET(url, timeout=8).content

    version = iwrapper(xml, 'addon', attrs={'id': kodi.addonInfo('id')}, ret='version').__next__()

    return version_tuple(version)


def version_tuple(version):
    """
    '2.0.10' -> (2, 0, 10), so versions compare as numbers per part. The old
    int(version.replace('.', '')) made 2.0.10 read as 2010 and 2.1.0 as 210, so once 2.0.10
    shipped nobody on it would have been told about anything up to 2.9.9.
    """

    parts = []

    for part in str(version).split('.'):
        digits = ''.join(c for c in part if c.isdigit())
        parts.append(int(digits) if digits else 0)

    return tuple(parts)


def version_text(version):

    return '.'.join(str(part) for part in version) if isinstance(version, tuple) else str(version)


########################################################################################################################


def rename_history_csv():

    try:
        if not kodi.exists(SEARCH_HISTORY):
            rename(SEARCH_HISTORY.replace('search_', ''), SEARCH_HISTORY)
    except Exception:
        pass


def checkpoint(check_updates=True):

    """
    Runs before every route. check_updates=False skips only the remote version check: the
    router passes it for a play click and for the source picker, so the 3-hourly GET of the
    repository index never delays a stream. Listings keep it (bounded to 8 s in
    remote_version(), at most once per 3 h), because a user who reaches the add-on only
    through a favourite or a home-screen widget never opens the root menu and would
    otherwise never see the new-version prompt.
    """

    check = time() + 10800

    rename_history_csv()

    if new_version():

        # The first-run / post-update welcome + disclaimer screen is opt-in.
        # It interrupts every update with a modal before the user can reach the
        # menu; kept in the codebase (and reachable from Settings) so it can be
        # switched back on from the add-on settings without a code change.
        if kodi.setting('show_welcome') == 'true':
            welcome()

        cache_clear()
        reset_idx(notify=False)
        clean_old_textures()

        if Addon().getSetting('debug') == 'true':

            log(
                'Debug settings have been reset, please do not touch these settings manually,'
                ' they are *only* meant to help developer test various aspects.'
            )

            kodi.setSetting('debug', 'false')

        kodi.setSetting('last_check', str(check))

    elif check_updates and Addon().getSetting('new_version_prompt') == 'true' and time() > float(Addon().getSetting('last_check') or '0'):

        try:
            newer = remote_version() > version_tuple(kodi.version())
        except Exception:  # network failure, or alpha/beta version strings failing int()
            newer = False

        if newer:
            prompt()

        kodi.setSetting('last_check', str(check))


def clean_old_textures():

    base_path = kodi.transPath('special://profile/')
    textures_path = kodi.join(base_path, 'Thumbnails')
    db_path = kodi.join(base_path, 'Database/Textures13.db')

    try:

        conn = sqlite3.connect(str(db_path))
        cursor = conn.cursor()

        # Find the cached filenames for your specific assets
        query = "SELECT cachedurl FROM texture WHERE url LIKE ? OR url LIKE ?"
        params = (f"%{kodi.addonInfo('id')}/icon.png", f"%{kodi.addonInfo('id')}/fanart.jpg")

        cursor.execute(query, params)
        rows = cursor.fetchall()

        for (cached_rel_path,) in rows:

            full_file_path = kodi.join(textures_path, cached_rel_path)

            if kodi.exists(full_file_path):
                kodi.deleteFile(full_file_path)

    except sqlite3.Error as e:
        log(f"Error reading database: {e}")
    finally:
        if 'conn' in locals():
            conn.close()


def page_selector(query):

    pages = [kodi.i18n(30415).format(i) for i in list(range(1, int(query) + 1))]

    _choice = kodi.selectDialog(pages, heading=kodi.i18n(30416))

    if _choice != -1:

        kodi.setSetting('page', str(_choice))
        kodi.sleep(200)
        kodi.refresh()

        if Addon().getSetting('pagination_reset') == 'true':
            # wait a second in order to ensure container is first loaded then reset the page
            kodi.sleep(1000)
            kodi.setSetting('page', '0')


def page_menu(pages, reset=False):

    if not reset:
        index = str(int(Addon().getSetting('page')) + 1)
    else:
        index = '1'

    menu = {
        'title': kodi.i18n(30414).format(index),
        'action': 'page_selector',
        'query': pages,
        'icon': iconname('switcher'),
        'isFolder': 'False',
        'isPlayable': 'False'
    }

    return menu


@cache_function(cache_duration(60))
def yt_playlist(url):

    from scrapetube.wrapper import list_playlist_videos

    return list_playlist_videos(url)

########################################################################################################################

def lists_merger(list_1, list_2, key='title'):

    merged_list = [dict(i) for i in list_1]

    matched_list_2_indices = set()

    list_2_lowered = [(i, item2, item2[key].lower()) for i, item2 in enumerate(list_2)]

    for item1 in merged_list:
        title1 = item1[key].lower().strip()

        for i, item2, title2 in list_2_lowered:

            if title1 in title2:

                if 'plot' in item2:
                    item1['plot'] = item2['plot']

                if 'image' in item2:
                    item1['image'] = item2['image']

                if 'genre' in item2:
                    item1['genre'] = item2['genre']

                matched_list_2_indices.add(i)

                break

    for i, item2 in enumerate(list_2):
        if i not in matched_list_2_indices:
            merged_list.append(item2)

    return sorted(merged_list, key=lambda x: x[key])


def import_alivegr_data():

    """Merge playback/search history and bookmarks from an AliveGR install."""

    from os import path
    from shutil import copyfile

    src_profile = kodi.transPath('special://profile/addon_data/plugin.video.alivegr/')
    if not path.exists(src_profile):
        kodi.infoDialog(kodi.i18n(30952))
        return

    merged = 0
    for name in ('playback_history.list', 'search_history.csv'):
        src = path.join(src_profile, name)
        dst = kodi.transPath('special://profile/addon_data/plugin.video.iparhotv/' + name)
        if not path.exists(src):
            continue
        with open(src, encoding='utf-8') as f:
            lines = [l.strip() for l in f if l.strip()]
        existing = set()
        if path.exists(dst):
            with open(dst, encoding='utf-8') as f:
                existing = set(l.strip() for l in f if l.strip())
        fresh = [l for l in lines if l not in existing]
        if fresh:
            with open(dst, 'a', encoding='utf-8', newline='') as f:
                f.write('\n'.join(fresh) + '\n')
            merged += len(fresh)

    src_db = path.join(src_profile, 'bookmarks.db')
    dst_db = kodi.transPath('special://profile/addon_data/plugin.video.iparhotv/bookmarks.db')
    if path.exists(src_db) and not path.exists(dst_db):
        copyfile(src_db, dst_db)
        merged += 1

    kodi.infoDialog(kodi.i18n(30953).format(merged))
